import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-course',
  template: `
    <div class='flex-item'>
    <h3>Course Name: {{ appCourse.name }}</h3>
    <h3>Description: {{ appCourse.desc }}</h3>
    <h3>Start Date: {{ appCourse.start }}</h3>
    <h3>End Date: {{ appCourse.end }}</h3>
    <button (click)="removeItem(this)">
    remove
    </button>
    </div>
  `,
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

    constructor() {
    }
  removeItem() {
        this.remove.emit(this.appCourse);
    };
  ngOnInit() {
  }
  @Input() appCourse: any;
  @Output() remove: EventEmitter<any> = new EventEmitter();
}
