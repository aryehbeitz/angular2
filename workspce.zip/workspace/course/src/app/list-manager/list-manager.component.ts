import { Component, OnInit } from '@angular/core';
import { AppListService } from '../app-list.service';
import { CourseComponent } from '../course/course.component';

@Component({
  selector: 'app-list-manager',
  template: `
    <div class="flex-container">
    <app-course-form (submit)="addItem($event)"></app-course-form>
    <ul>
      <li *ngFor="let course of appList">
          <app-course [appCourse]="course" 
          (remove)="removeItem($event)"
           ></app-course>
      </li>
    </ul>
    </div>
    `,
  styleUrls: ['./list-manager.component.css']
})

export class ListManagerComponent implements OnInit {
    private appList;
    constructor(private appListService: AppListService) { }
    ngOnInit() {
        this.appList = this.appListService.getAppList();
    }
    addItem(course: Object) {
        if (!course['isTrusted']) {
            this.appList = this.appListService.addItem(course);
        }
    }
    removeItem(item) {
    this.appList = this.appListService.removeItem(item);
}

}
