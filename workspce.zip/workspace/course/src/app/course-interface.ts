export interface CourseInterface {
    id: number,
    name: string,
    desc: string,
    start: string,
    end: string
}
