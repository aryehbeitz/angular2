import { Injectable } from '@angular/core';
import { AppListStorageService } from './app-list-storage.service';

@Injectable()
export class AppListService {
 
  constructor(private storage:AppListStorageService) { }
  addItem(course) {
    return this.storage.post(course);
    }
  getAppList() {
      return this.storage.get();
  }
  removeItem(course) {
  return this.storage.destroy(course);
}

}
