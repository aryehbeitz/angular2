import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { CourseComponent } from '../course/course.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-course-form',
  templateUrl: './course-form.component.html',
  styleUrls: ['./course-form.component.css']
})
export class CourseFormComponent implements OnInit {
    course: FormGroup;
    constructor(private fb: FormBuilder) { }

    ngOnInit() {
        this.course = this.fb.group({
            name: ['', [Validators.required, Validators.minLength(2)]],
            id: ['', [Validators.required, Validators.minLength(2)]],
            desc: ['', [Validators.required, Validators.minLength(2)]],
            start: ['', [Validators.required, Validators.minLength(2)]],
            end: ['', [Validators.required, Validators.minLength(2)]]
        });
  }
    onSubmit() {
        this.submit.emit(this.course.value);
        }

    @Output() submit: EventEmitter<Object> = new EventEmitter();
}
