/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AppListStorageService } from './app-list-storage.service';

describe('AppListStorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppListStorageService]
    });
  });

  it('should ...', inject([AppListStorageService], (service: AppListStorageService) => {
    expect(service).toBeTruthy();
  }));
});
