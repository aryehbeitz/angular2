import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';


@Injectable()
export class CoursesService {
    private appList;
    constructor(private http: Http) { }
    private BaseUrl: string = `https://coursedb.herokuapp.com/`;

    get() {
        
    }

    logError(err) {
        console.error('There was an error: ' + err);
    }
}
