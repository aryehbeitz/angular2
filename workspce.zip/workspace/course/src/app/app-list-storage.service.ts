import { Injectable } from '@angular/core';
import { HttpModule, JsonpModule, Http, Response } from '@angular/http';

const storageName = 'aah_app_list';
const defaultList = [
    { id: 1, name: "Intro to Angular 2", desc: "Basic course for beginners in Angular 2", start: "1 Dec 2016", end: "8 Mar 2017" },
    { id: 2, name: "Intro to NodeJS", desc: "Basic course for beginners in NodeJS", start: "1 Dec 2016", end: "8 Mar 2017" },
    { id: 3, name: "Intro to MongoDB", desc: "Basic course for beginners in MongoDB", start: "1 Dec 2016", end: "8 Mar 2017" }
];
@Injectable()
export class AppListStorageService {
    private appList;
    private courseUrl = 'https://coursedb.herokuapp.com/';  // URL to web api

   constructor(private http: Http) { this.appList = JSON.parse(localStorage.getItem(storageName)) || defaultList;  }
    // get items
  get() {
        return [...this.appList];
  };

  // add a new item
  post(item) {
      this.appList.push(item);
      return this.update();
  };

  // update an item
  put(item, changes) {
    Object.assign(this.appList[this.findItemIndex(item)], changes);
    return this.update();
  };

  // remove an item
  destroy(item) {
      if (this.findItemIndex(item) > -1) {
          this.appList.splice(this.findItemIndex(item), 1);
          return this.update();
      }
  };
  
  private update() {
    localStorage.setItem(storageName, JSON.stringify(this.appList));

    return this.get();
  }
  
  private findItemIndex(item) {
    return this.appList.indexOf(item);
  }
}
