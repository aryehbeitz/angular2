import { Component, OnInit, Output, EventEmitter  } from '@angular/core';

@Component({
    selector: 'app-input',
    template: `                           
            <input [value]="title"              
           (keyup.enter)="changeTitle($event.target.value)" 
            #myInput>

            <button (click)="changeTitle(myInput.value)">
              Save
            </button>
            {{ title }}
  `,
    styleUrls: ['./input.component.css']
})
export class InputComponent implements OnInit {
    private title: string = '';    
    constructor() { }
    
    ngOnInit() {
    }
    changeTitle(newTitle: string): void {
        this.submit.emit(newTitle);
    };
    @Output() submit: EventEmitter<string> = new EventEmitter();
}