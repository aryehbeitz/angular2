import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-item',
  template: `
    {{ appItem.title }}
    <button (click)="removeItem(this)">
    remove
    </button>
  `,
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  constructor() { }
  removeItem() {
      this.remove.emit(this.appItem);
    };
  ngOnInit() {
    
  }
  @Input() appItem: any;
  @Output() remove:EventEmitter<any> = new EventEmitter();
  
}
